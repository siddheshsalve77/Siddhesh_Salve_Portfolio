
  # Siddhesh Salve Portfolio

  This is a code bundle for Siddhesh Salve Portfolio. The original project is available at https://www.figma.com/design/YVj78JjvzoQOfGJlP370fx/Siddhesh-Salve-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  